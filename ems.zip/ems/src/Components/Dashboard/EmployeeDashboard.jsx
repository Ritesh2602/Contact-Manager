import { Header } from "../other/Header";
import { TaskListNumber } from "../other/TaskListNumber";
import { TaskList } from "../TaskList/TaskList";

export const EmployeeDashboard = (props) => {
  // console.log(typeof(data))
  // console.log(Object.keys(data));
  return (
    <div className="p-10 bg-[#1C1C1C] h-screen">
      <Header changeUser={props.changeUser} data={props.data}></Header>
      <TaskListNumber data={props.data}></TaskListNumber>
      <TaskList data={props.data}></TaskList>
    </div>
  );
};
